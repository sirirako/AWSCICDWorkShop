#!/bin/bash
cd /home/ec2-user/node-website
export PORT=80
forever start app.js