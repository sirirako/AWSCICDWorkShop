#!/bin/bash
pkill -f node
